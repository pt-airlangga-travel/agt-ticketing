<?php

namespace Modules\PengajuanDana\Filament\Clusters\PengajuanDana\Resources\ProposalDrafts\Pages;

use Filament\Actions\DeleteAction;
use Filament\Resources\Pages\EditRecord;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use Modules\PengajuanDana\Enums\ProposalSubmissionStatus;
use Modules\PengajuanDana\Filament\Clusters\PengajuanDana\Concerns\HasClusterSubNavigation;
use Modules\PengajuanDana\Filament\Clusters\PengajuanDana\Resources\ProposalDrafts\ProposalDraftResource;

class EditProposalDraft extends EditRecord
{
    use HasClusterSubNavigation;

    protected static string $resource = ProposalDraftResource::class;

    protected function getHeaderActions(): array
    {
        return [
            DeleteAction::make(),
        ];
    }

    public function getTitle(): string
    {
        return 'Ubah';
    }

    protected function mutateFormDataBeforeFill(array $data): array
    {
        $submission = $this->record->submissions()
            ->where('status', ProposalSubmissionStatus::Menunggu->value)
            ->latest('id')
            ->first();

        if ($submission) {
            $data['needs'] = $submission->needs()->pluck('judan_needs.id')->all();
        }

        return $data;
    }

    protected function handleRecordUpdate(Model $record, array $data): Model
    {
        return DB::transaction(function () use ($record, $data): Model {
            $record = parent::handleRecordUpdate($record, $data);

            $submission = $record->submissions()
                ->where('status', ProposalSubmissionStatus::Menunggu->value)
                ->latest('id')
                ->first();

            if ($submission) {
                $submission->needs()->sync($data['needs'] ?? []);
            }

            return $record;
        });
    }
}

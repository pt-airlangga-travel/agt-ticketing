<?php

return [
    'name' => 'PengajuanDana',
];

<?php

return [
    'name' => 'Ticketing',
];
